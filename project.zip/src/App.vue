<template>
  <div id="app">
    <!-- <img alt="Vue logo" src="./assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/> -->
    <Header />
    <search />
    <Footer />
    
  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
import Header from './components/Header'
import search from './components/search'
import Footer from './components/Footer'



export default {
  name: 'App',
  components: {
    // HelloWorld
    Header,
    search,
    Footer,  
  
  }
}
    
</script>


