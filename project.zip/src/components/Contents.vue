<template>
       <div class="content">
            <h2>List of transactions</h2>
            <span>
            <button>Create New</button>
            </span>
        </div>
    
</template>

<style>
.content{
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    
}

</style>