<template>
    <footer class="foot">
        <i class="fa fa-home" aria-hidden="true"> 1 of 6> </i>
    </footer>
</template>

<style>
.foot{
    text-align: center;
    font-size: 17px;
    padding: 10px;
    

}
</style>