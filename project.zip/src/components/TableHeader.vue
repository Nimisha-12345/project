<template>
    <thead>
        <tr>
            <th><i class="fa fa-square-o"></i></th>  
            <th>Transaction ID</th>
            <th>Transaction Name</th>
            <th> Email</th>
            <th>Type</th>
            <th>date</th>
            <th>Items</th>
            <th>Amount</th>
            <th>Action</th>
        </tr>
    </thead>
</template>



<style  scoped>
thead{
    background: #19174a;
    color: white;
}

th{
     padding: 15px;
    
}

</style>